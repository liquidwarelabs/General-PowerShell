$OSTSharepath="\\js-pro.foo.local\ProfileShare"

if( -Not (Test-Path -Path $OSTSharepath\$env:username ) )
{
    New-Item -ItemType directory -Path $OSTSharepath\$env:username
    Start-Sleep -Seconds 2
}

Remove-Item $env:userprofile\ostdisk -force
new-item -Path "$env:userprofile\ostdisk" -ItemType directory
Rename-Item -Path "$env:userprofile\AppData\Local\Microsoft\Outlook\" -NewName "$env:userprofile\AppData\Local\Microsoft\Outlook.old\"
new-item -Path "$env:userprofile\AppData\Local\Microsoft\Outlook\" -ItemType directory

$diskpartconfig=@()
$diskpartconfig=$diskpartconfig += "create vdisk file=$OSTSharepath\$env:username\OST.vhd maximum=20000 type=expandable"
$diskpartconfig=$diskpartconfig += "attach vdisk"
$diskpartconfig=$diskpartconfig += "create partition primary"
$diskpartconfig=$diskpartconfig += 'format fs=ntfs label="OSTDisk" quick'
$diskpartconfig=$diskpartconfig += "assign mount=$Env:userprofile\AppData\Local\Microsoft\Outlook\"
$diskpartconfig | out-file c:\temp\OSTconfig.txt -Encoding default

$diskpartdetach=@()
$diskpartdetach=$diskpartdetach += "select vdisk file=$OSTSharepath\$env:username\OST.vhd"
$diskpartdetach=$diskpartdetach += "detach vdisk"
$diskpartdetach | out-file c:\temp\OSTdetach.txt -Encoding default

$diskpartattach=@()
$diskpartattach=$diskpartattach += "AUTOMOUNT DISABLE"
$diskpartattach=$diskpartattach += "select vdisk file=$OSTSharepath\$env:username\OST.vhd"
$diskpartattach=$diskpartattach += "attach vdisk"
$diskpartattach=$diskpartattach += "select partition 1"
$diskpartattach=$diskpartattach += "assign mount=$env:userprofile\AppData\Local\Microsoft\Outlook\"
$diskpartattach=$diskpartattach += "AUTOMOUNT ENABLED"
$diskpartattach | out-file c:\temp\OSTattach.txt -Encoding default

$CMDfile=@()
$CMDfile=$CMDfile +=  'if exist' + " " + "$OSTSharepath\$env:username\OST.vhd"  + " " + '(c:\windows\system32\cmd.exe /c diskpart /s "c:\temp\OSTattach.txt") else (c:\windows\system32\cmd.exe /c diskpart /s "c:\temp\OSTconfig.txt")'
$CMDfile | out-file c:\temp\OSTCMD.bat -Encoding default
